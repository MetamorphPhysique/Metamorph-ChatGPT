OFF-PLAN MEALS — FINISHED CAROUSEL

The finished PNGs are supplied in off-plan-meals-slides.zip.
Upload those six PNG files in filename order.
Every slide is 1080 x 1350 pixels (4:5 portrait).
carousel-preview.png shows all six slides at phone scale.

EDITING
The six editable/ SVG files contain live text, original vector diagrams and
an embedded shared photographic background. Open in Inkscape or another
SVG editor. Install fonts/NimbusSans-Bold.otf for predictable text layout.
Nimbus Sans substitutes for Helvetica Neue, which was unavailable.

The shared background has its own editable SVG in assets/background/:
the photograph and dark gradient are separate layers. Its matching PNG is
the exact shared layer used in every slide. The original uploaded photo is
preserved in assets/source/. Four reusable diagram SVGs and transparent PNGs
are in assets/graphics/.

slide-copy.txt contains all visible wording, including diagram labels.
slide-data.json contains the layout's structured copy.
source-notes.md records source access, editorial qualifications and checks.

REPRODUCTION
The artwork is already rendered; no commands are required to use the PNGs.
For programmatic revisions, build_carousel.py regenerates slides from the
included shared background and diagrams. It requires Python 3 with Pillow,
Inkscape, ImageMagick and the supplied font installed. It also checks that
the protected face region remains pixel-identical to the shared background.

The photograph was not regenerated. The reel's wording was obtained from
the two user-supplied transcript screenshots; its video was inaccessible.

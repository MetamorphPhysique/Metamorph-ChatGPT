# Off-plan meals — source and delivery notes

## Source material

- Reel supplied by the user: https://www.instagram.com/reel/DeGmL4CtisY/
- `IMG_2923.heic`: user-supplied screenshot of a caption editor, approximately 00:00–00:54. Covers planning smaller meals earlier, the speaker's personal calorie example, and putting protein on the plate first.
- `IMG_2924.heic`: user-supplied screenshot of the same caption editor, approximately 00:33–01:26. Covers protein, the social occasion, and the closing like/follow CTA.
- Both transcript screenshots were visually inspected. The reel page and public embed returned a proxy connection error, `403 Forbidden`. The video and audio were not inspected. No footage-derived graphics or source video frames are included.
- Background photograph: `unnamed.jpg`, successfully extracted from the user's `BBQ Pic.zip`. Original size: 1206 × 1686. The original file is included in `assets/source/`.

## Editorial choices

- Preserve the source's sequence: planning flexibility, protein first, then social focus.
- Split the protein/starter discussion across two teaching slides, keeping starters and main meals positive.
- Omit the speaker's personal calorie figures: approximately 1,500 for dinner and 1,000–1,200 earlier. These are personal examples, not universal targets.
- “Avoid skipping meals or arriving ravenous” is an editorial qualification, not a quotation from the source.
- Use “can help” for protein and satisfaction, without guaranteed fullness or weight outcomes.
- Do not repeat the claim that a meal can cost someone “all” their progress.
- Omit an unclear food name in the automatic captions.
- The source CTA is like/follow. The carousel uses an honest save/follow CTA and promises no resource, service or message delivery.
- The complete visible wording, including diagram labels, is in `slide-copy.txt`.

## Graphics and typography

- The four teaching graphics are original editable vector illustrations, not factual evidence, product screenshots, or exact portion prescriptions.
- `flexibility.svg`: earlier meals → dinner, with illustrative meal plates.
- `protein.svg`: a protein-containing meal, with a labelled pointer.
- `starters.svg`: bread alongside a main meal; neither food is crossed out or treated as forbidden.
- `company.svg`: conversation bubbles with the label “Good food. Good company.”
- No externally sourced artwork, creator watermarks, stock photography or generative artwork was used. There are no image-generation prompts to disclose. The authentic barbecue photograph supplies the cover imagery.
- Helvetica Neue was unavailable. Nimbus Sans Bold was used as a close clean sans-serif substitute. Bundled font files and their license are in `fonts/`.

## Photograph treatment and verification

- Crop: source rectangle `(3, 150)` to `(1203, 1650)`, resized to 1080 × 1350 without stretching.
- One identical shared photograph layer is used on every slide.
- One consistent black gradient starts below the head, at output y=380, and darkens the lower text area.
- The original face, expression, hair, beard, body, clothing and photographic texture were not regenerated or retouched.
- The protected rectangle `(470, 50)` to `(720, 375)` is pixel-identical to the cropped original on all six slides.
- The complete upper 450 pixels of every slide are identical to the shared background; no foreground elements enter that region.
- All six exports are exactly 1080 × 1350. Every slide was inspected at full resolution and approximately 360 pixels wide. Text and illustrations are legible and unclipped; the cover and CTA are centered.

## Access and export limitations

- Attempts to retrieve NHS balanced-diet guidance and a PubMed protein review were blocked by the network proxy. Neither is represented as a verified external source. The copy uses general, qualified guidance and no personalized calorie prescription.
- The final PNGs are flattened for posting. The corresponding SVGs retain editable text and vector graphics; the photograph remains a raster layer. Its crop and shading are also supplied as a separate background project.
- Install the bundled Nimbus Sans font for predictable text editing. SVG viewers differ in support for embedded fonts and Inkscape layer metadata.
- The source transcript screenshots are references, not part of the posted artwork. The full source video was unavailable.
- No publishing, messaging, account access or other external action was performed.

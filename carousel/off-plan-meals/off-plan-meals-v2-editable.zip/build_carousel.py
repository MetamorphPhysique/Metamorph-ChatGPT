#!/usr/bin/env python3
"""Build the supplied photo and editable vector layers into seven finished slides.

Run from any working directory. Requires Python, Pillow, Inkscape and ImageMagick.
The source photograph is never generated or retouched. Background crop and
gradient are separately editable in assets/background/shared-background.svg.
"""
from pathlib import Path
import base64
import json
import re
import sys
import subprocess
from xml.sax.saxutils import escape
from PIL import Image, ImageFont, ImageChops

ROOT = Path(__file__).resolve().parent
FONT = ROOT / 'fonts/NimbusSans-Bold.otf'
SLIDES = [
    {'slug':'01-cover','kind':'cover',
     'lines':['Enjoy off-plan','meals without','overdoing it.']},
    {'slug':'02-plan-some-flexibility','kind':'teaching','graphic':'flexibility.svg',
     'graphic_labels':['Earlier meals','Dinner'],
     'title':'Plan some flexibility',
     'lines':['If a bigger dinner is planned,','slightly smaller, satisfying meals',
              'earlier may suit you. Avoid skipping','meals or arriving ravenous.']},
    {'slug':'03-start-with-protein','kind':'teaching','graphic':'protein.svg',
     'graphic_labels':['Protein first'],
     'title':'Start with protein',
     'lines':['Start your plate with a protein','source you enjoy. It can help you',
              'feel satisfied and support your','usual protein intake.']},
    {'slug':'04-leave-room-for-your-meal','kind':'teaching','graphic':'starters.svg',
     'graphic_labels':['Starters','Main meal'],
     'title':'Leave room for your meal',
     'lines':['Enjoy the bread or starters','you want. Leave space for your',
              'main meal too, rather than filling','up before it arrives.']},
    {'slug':'05-enjoy-the-company','kind':'teaching','graphic':'company.svg',
     'graphic_labels':['People first. Food is a bonus.'],
     'title':'Enjoy the company',
     'lines':['Make the people and the occasion','your priority. Enjoy the company.',
              'The food is just a bonus.']},
    {'slug':'06-next-meal-back-to-normal','kind':'teaching','graphic':'next-meal.svg',
     'graphic_labels':['One meal','Next meal: normal'],
     'title':'Next meal: back to normal',
     'lines':['It’s one meal, not a cheat week.','At the very next meal, go straight',
              'back to your normal routine.']},
    {'slug':'07-save-and-follow','kind':'cta',
     'lines':['Save this for your','next meal out.'],
     'support':['Follow for more practical','nutrition tips.']}
]

def image_uri(path):
    return 'data:image/png;base64,' + base64.b64encode(path.read_bytes()).decode()

def text_line(value,x,y,size=54,color='#FFFFFF',anchor='start'):
    f=ImageFont.truetype(str(FONT),size)
    width=f.getlength(value)
    left=x-width/2 if anchor=='middle' else x
    assert left>=60 and left+width<=1020, (value,size,left,width)
    assert y-size>=400 and y+size*.25<=1290, (value,y)
    return (f'<text x="{x}" y="{y}" font-size="{size}" '
            f'text-anchor="{anchor}" fill="{color}" '
            f'font-family="Nimbus Sans" font-weight="700">{escape(value)}</text>')

def graphic_markup(filename,prefix):
    s=(ROOT/'assets/graphics'/filename).read_text()
    s=re.sub(r'<\?xml.*?\?>','',s,flags=re.S)
    s=re.sub(r'<!DOCTYPE.*?>','',s,flags=re.S)
    s=re.sub(r'^\s*<svg\b[^>]*>','',s,flags=re.S)
    s=re.sub(r'</svg>\s*$','',s)
    # Keep a diagram's label styling from overriding the slide typography.
    s=s.replace('<style>text{','<style>#teaching-diagram text{')
    for ident in set(re.findall(r'\bid="([^"]+)"',s)):
        s=s.replace('id="'+ident+'"','id="'+prefix+ident+'"')
        s=s.replace('url(#'+ident+')','url(#'+prefix+ident+')')
        s=s.replace('href="#'+ident+'"','href="#'+prefix+ident+'"')
    return f'<g id="teaching-diagram" transform="translate(140,480)">{s}</g>'

def build(only=None):
    for name in ['slides','editable','qa']:
        (ROOT/name).mkdir(exist_ok=True)
    bg=image_uri(ROOT/'assets/background/shared-background.png')
    font64=base64.b64encode(FONT.read_bytes()).decode()
    results=[]
    for idx, slide in enumerate(SLIDES):
        layers=[]
        if slide['kind']=='cover':
            for i,line in enumerate(slide['lines']):
                layers.append(text_line(line,540,780+i*112,106,
                              '#FFCC00' if i==2 else '#FFFFFF','middle'))
        elif slide['kind']=='teaching':
            layers.append(graphic_markup(slide['graphic'],f'g{idx}-'))
            layers.append(text_line(slide['title'],80,861,70,'#FFCC00'))
            for i,line in enumerate(slide['lines']):
                layers.append(text_line(line,80,950+i*61,54))
        else:
            for i,line in enumerate(slide['lines']):
                layers.append(text_line(line,540,810+i*84,78,
                              '#FFCC00' if i==0 else '#FFFFFF','middle'))
            for i,line in enumerate(slide['support']):
                layers.append(text_line(line,540,1000+i*63,56,'#FFFFFF','middle'))
        svg=f'''<svg xmlns="http://www.w3.org/2000/svg"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
 width="1080" height="1350" viewBox="0 0 1080 1350">
<title>{escape(slide['slug'])}</title>
<desc>Original user photograph with editable text and original vector teaching graphic. Off-plan meals carousel.</desc>
<defs><style>@font-face {{font-family:'Nimbus Sans';font-weight:700;src:url(data:font/otf;base64,{font64}) format('opentype');}}</style>
<filter id="type-shadow" x="-10%" y="-15%" width="120%" height="140%"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#000000" flood-opacity="0.2"/></filter></defs>
<g id="shared-photograph" inkscape:groupmode="layer" inkscape:label="Shared photograph and shading"><image width="1080" height="1350" xlink:href="{bg}"/></g>
<g id="editable-design" inkscape:groupmode="layer" inkscape:label="Editable graphics and copy">{''.join(layers)}</g>
</svg>'''
        source=ROOT/'editable'/(slide['slug']+'.svg')
        output=ROOT/'slides'/(slide['slug']+'.png')
        reuse=only is not None and slide['slug'] not in only
        if reuse:
            assert source.exists() and output.exists(), slide['slug']
        else:
            source.write_text(svg)
            proc=subprocess.run(['inkscape',str(source),'--export-type=png',
                                 '--export-filename='+str(output)],capture_output=True,text=True)
            if proc.returncode:
                raise RuntimeError(proc.stderr)
        im=Image.open(output).convert('RGB')
        base=Image.open(ROOT/'assets/background/shared-background.png').convert('RGB')
        assert im.size==(1080,1350), im.size
        protected=(470,50,720,375)
        diff=ImageChops.difference(im.crop(protected),base.crop(protected))
        assert diff.getbbox() is None, f'Face changed in {slide["slug"]}'
        results.append({'slide':slide['slug'],'size':list(im.size),
                        'protected_face_pixels_identical':True})
        print('Reused' if reuse else 'Rendered',output.name,flush=True)
    (ROOT/'slide-data.json').write_text(json.dumps(SLIDES,indent=2)+'\n')
    (ROOT/'qa/checks.json').write_text(json.dumps(results,indent=2)+'\n')
    plain=['OFF-PLAN MEALS — FINAL SLIDE COPY','']
    for slide in SLIDES:
        plain.append(slide['slug'].upper())
        if 'graphic_labels' in slide:
            plain.append('Diagram labels: ' + ' / '.join(slide['graphic_labels']))
        if 'title' in slide:
            plain.append(slide['title'])
        plain.extend(slide['lines'])
        if 'support' in slide:
            plain.extend(['']+slide['support'])
        plain.append('')
    (ROOT/'slide-copy.txt').write_text('\n'.join(plain))
    pngs=[str(ROOT/'slides'/(s['slug']+'.png')) for s in SLIDES]
    rows=[]
    for i in range(0,len(pngs),4):
        row=ROOT/'qa'/f'preview-row-{i//4}.png'
        subset=pngs[i:i+4]
        subprocess.run(['magick','montage',*subset,'-thumbnail','360x450',
                        '-tile',f'{len(subset)}x1','-geometry','360x450+12+12',
                        '-background','#171A1E',str(row)],check=True)
        subprocess.run(['magick',str(row),'-background','#171A1E','-gravity',
                        'center','-extent','1536x474',str(row)],check=True)
        rows.append(str(row))
    subprocess.run(['magick',*rows,'-append',str(ROOT/'carousel-preview.png')],check=True)
    for source in pngs:
        subprocess.run(['magick',source,'-resize','360x450',
                        str(ROOT/'qa'/Path(source).name)],check=True)
    print(f'All {len(SLIDES)} slides ready; exact dimensions and protected face pixels verified.')

if __name__=='__main__':
    build(set(sys.argv[1:]) or None)
